self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6c09331757186ed70e8dcb0a63e9020e",
    "url": "/index.html"
  },
  {
    "revision": "dce7118487a90e9e1e3a",
    "url": "/static/css/main.cb2322a4.chunk.css"
  },
  {
    "revision": "b913fb90d809c7d02599",
    "url": "/static/js/2.c026374a.chunk.js"
  },
  {
    "revision": "dce7118487a90e9e1e3a",
    "url": "/static/js/main.ee0800b9.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "36669cd64fab93fe378bc5b6ddd9c007",
    "url": "/static/media/Reset.36669cd6.PNG"
  },
  {
    "revision": "f00b9c012ab16f4c97ad6420b52ea53b",
    "url": "/static/media/avengers.f00b9c01.jpg"
  },
  {
    "revision": "e643a6cf77b4635dda856f10fa9b7db4",
    "url": "/static/media/bg11.e643a6cf.jpg"
  },
  {
    "revision": "b21019516fd574253e2354080dc1dd00",
    "url": "/static/media/login.b2101951.jpg"
  },
  {
    "revision": "6420532ea4c480b06f7d1d98d9d36aa4",
    "url": "/static/media/movie.6420532e.jpg"
  },
  {
    "revision": "22a0bffe789c286a9d78eb52670996a7",
    "url": "/static/media/nucleo-outline.22a0bffe.ttf"
  },
  {
    "revision": "24e2d6b43b1b0f84fdfaa06a4032f154",
    "url": "/static/media/nucleo-outline.24e2d6b4.woff"
  },
  {
    "revision": "53a1bed7a3ec86d010fe100873828a89",
    "url": "/static/media/nucleo-outline.53a1bed7.eot"
  },
  {
    "revision": "8ebec31f5ce59f908db84d86aed5947f",
    "url": "/static/media/nucleo-outline.8ebec31f.woff2"
  }
]);